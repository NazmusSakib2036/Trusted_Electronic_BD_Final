@extends('frontend.layouts.app')

@section('title', 'Trusted Electronics BD - Home')

@section('content')
    <div x-data="homeStore()" x-init="init()">
        
        <section class="bg-gray-50 py-8 shadow-inner">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8"> 
                
                <div class="flex items-center space-x-4 overflow-x-auto pb-4 custom-scrollbar">
                    
                    <div class="category-card flex-shrink-0 cursor-pointer group" @click="selectCategory(null)">
                        <div :class="selectedCategory === null ? 'gradient-bg text-white shadow-lg border-2 p-5 border-transparent' : 'bg-white hover:bg-blue-50 border border-gray-200 text-gray-700 hover:text-blue-600'"
                            class="p-5 sm:p-7 rounded-xl text-center min-w-[140px] sm:min-w-[160px] transition duration-300 ease-in-out transform hover:-translate-y-0.5 hover:shadow-lg border-red-500">
                            <div class="text-8x5 sm:text-5xl mb-3 transition duration-300" 
                                :class="selectedCategory === null ? 'text-white' : 'text-white-500 group-hover:text-blue-600'">
                                ✨
                            </div>
                            <h3 class="font-bold text-base sm:text-lg" style="padding: 1.6rem .5rem; border: none;">সব ক্যাটাগরি</h3>
                        </div>
                    </div>

                    <template x-for="category in categories" :key="category.id">
                        <div class="category-card flex-shrink-0 cursor-pointer group" @click="selectCategory(category.id)">
                            <div :class="selectedCategory === category.id ? 'gradient-bg text-white shadow-lg border-2 border-transparent' : 'bg-white hover:bg-gray-100 border border-gray-200 text-gray-800'"
                                class="p-5 sm:p-7 rounded-xl text-center min-w-[140px] sm:min-w-[160px] transition duration-300 ease-in-out transform hover:-translate-y-0.5 hover:shadow-lg border-red-500">
                                
                                <div class="mb-3">
                                    <img x-show="category.image" :src="category.image" :alt="category.name"
                                        class="w-20 h-20 sm:w-24 sm:h-24 mx-auto object-fit rounded-lg shadow-md group-hover:shadow-xl transition duration-300">
                                    
                                    <div x-show="!category.image"
                                        :class="selectedCategory === category.id ? 'bg-white bg-opacity-20 text-white' : 'bg-blue-500 text-white'"
                                        class="w-12 h-12 sm:w-14 sm:h-14 mx-auto rounded-full flex items-center justify-center font-extrabold text-xl sm:text-2xl shadow-md">
                                        <span x-text="category.name.charAt(0).toUpperCase()"></span>
                                    </div>
                                </div>
                                
                                <h3 class="font-semibold text-base sm:text-lg" x-text="category.name"></h3>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </section>

        <style>
        /* For Webkit browsers (Chrome, Safari) */
        .custom-scrollbar::-webkit-scrollbar {
            height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }
        </style>

        <section class="py-8">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 space-y-4 sm:space-y-0">
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900"
                            x-text="selectedCategory ? (categories.find(c => c.id === selectedCategory)?.name || 'পণ্যসমূহ') : 'সব পণ্য'">
                        </h2>
                        <p class="text-sm text-gray-600 mt-1" x-text="filteredProducts.length + ' products found'"></p>
                    </div>

                    <div
                        class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
                        <div class="relative">
                            <input type="text" x-model="searchQuery" @input="filterProducts()"
                                placeholder="Search products..."
                                class="w-full sm:w-64 border border-gray-300 rounded px-3 py-2 pl-10 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <svg class="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                </svg>
                            </div>
                        </div>

                        <div class="flex items-center space-x-2">
                            <span class="text-sm text-gray-600 whitespace-nowrap">Sort by:</span>
                            <select x-model="sortBy" @change="sortProducts()"
                                class="border border-gray-300 rounded px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="default">Default</option>
                                <option value="price_low">Price: Low to High</option>
                                <option value="price_high">Price: High to Low</option>
                                <option value="name">Name A-Z</option>
                                <option value="newest">Newest First</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div x-show="loading" class="text-center py-12">
                    <div class="inline-flex items-center">
                        <svg class="animate-spin -ml-1 mr-3 h-8 w-8 text-blue-500" xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4">
                            </circle>
                            <path class="opacity-75" fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                            </path>
                        </svg>
                        <span class="text-lg">Loading products...</span>
                    </div>
                </div>

                <div x-show="!loading"
                    class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <template x-for="product in filteredProducts" :key="product.id">
                        <div class="product-card bg-white rounded-lg shadow-md overflow-hidden border">


                            <div x-show="product.sale_price" class="relative">
                                <div class="absolute top-2 left-2 z-10">
                                    <span class="bg-green-500 text-white text-xs px-2 py-1 rounded"
                                        x-text="'Save ' + (product.price - product.sale_price) + ' BDT'">
                                    </span>
                                </div>
                            </div>

                            <div class="aspect-square bg-gray-100 relative overflow-hidden cursor-pointer"
                                @click="viewProduct(product.id)">
                                <img x-show="product.images && product.images.length > 0" 
     :src="product.images[0]" 
     :alt="product.name" 
     class="w-full h-full object-cover hover:scale-110 transition-transform duration-300" 
     
     src="/storage/products/product_1758953011_68d77e33b1376.jpg" 
     alt="20000mAh Power Bank Case – Without Battery">
                                <div x-show="!product.images || product.images.length === 0"
                                    class="w-full h-full flex items-center justify-center text-gray-400">
                                    <svg class="w-16 h-16" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" 
                                            d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </div>

                            <div class="p-4">
                                <h3 class="font-medium text-gray-900 mb-2 line-clamp-2 cursor-pointer hover:text-blue-600"
                                    @click="viewProduct(product.id)" x-text="product.name"></h3>

                                <div class="mb-3">
                                    <div x-show="product.sale_price" class="flex items-center space-x-2">
                                        <span class="text-lg font-bold text-green-600"
                                            x-text="'Tk ' + product.sale_price"></span>
                                        <span class="text-sm text-gray-500 line-through"
                                            x-text="'Tk ' + product.price"></span>
                                    </div>
                                    <div x-show="!product.sale_price">
                                        <span class="text-lg font-bold text-gray-900" x-text="'Tk ' + product.price"></span>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div x-show="product.stock_quantity > 0" class="text-sm text-green-600">
                                        <span x-text="'স্টক: ' + product.stock_quantity + 'টি উপলব্ধ'"></span>
                                    </div>
                                    <div x-show="product.stock_quantity === 0" class="text-sm text-red-600 font-medium">
                                        Out of Stock
                                    </div>
                                </div>

                                <div class="space-y-2">
                                    <button @click="addToCart(product)" :disabled="product.stock_quantity === 0"
                                        :class="product.stock_quantity === 0 ? 
                                                            'w-full bg-gray-300 text-gray-500 text-sm py-2 px-4 rounded cursor-not-allowed' : 
                                                            'w-full bg-gray-200 hover:bg-gray-300 text-gray-800 text-sm py-2 px-4 rounded transition-colors'">
                                        <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M17 13v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6" />
                                        </svg>
                                        <span x-text="product.stock_quantity === 0 ? 'স্টকে নেই' : 'কার্টে যোগ করুন'"></span>
                                    </button>
                                    <button @click="buyNow(product)" :disabled="product.stock_quantity === 0"
                                        :class="product.stock_quantity === 0 ? 
                                                            'w-full bg-gray-400 text-gray-500 text-sm py-2 px-4 rounded cursor-not-allowed' : 
                                                            'w-full bg-purple-600 hover:bg-purple-700 text-white text-sm py-2 px-4 rounded transition-colors'">
                                        <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M13 10V3L4 14h7v7l9-11h-7z" />
                                        </svg>
                                        <span x-text="product.stock_quantity === 0 ? 'স্টকে নেই' : 'এখনই কিনুন'"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </template>
                </div>

                <div x-show="!loading && filteredProducts.length === 0" class="text-center py-12">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2M4 13h2m8-5v5" />
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">No products found</h3>
                    <p class="mt-1 text-sm text-gray-500">Try adjusting your search or filter criteria.</p>
                </div>
            </div>
        </section>

        <div x-show="notification.show" x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 transform translate-y-2"
            x-transition:enter-end="opacity-100 transform translate-y-0"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform translate-y-2" class="fixed bottom-4 right-4 z-50">
            <div :class="{
                            'bg-green-500': notification.type === 'success',
                            'bg-red-500': notification.type === 'error',
                            'bg-blue-500': notification.type === 'info'
                        }" class="text-white px-6 py-4 rounded-lg shadow-lg">
                <p x-text="notification.message"></p>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            function homeStore() {
                return {
                    products: [],
                    filteredProducts: [],
                    categories: [],
                    loading: true,
                    selectedCategory: null,
                    sortBy: 'default',
                    searchQuery: '',
                    notification: {
                        show: false,
                        message: '',
                        type: 'success'
                    },

                    async init() {
                        try {
                            // Get search query from URL parameters
                            const urlParams = new URLSearchParams(window.location.search);
                            const searchParam = urlParams.get('search');
                            if (searchParam) {
                                this.searchQuery = decodeURIComponent(searchParam);
                            }

                            // Listen for navigation search events
                            window.addEventListener('navigationSearch', (event) => {
                                console.log('Home page received navigationSearch event:', event.detail);
                                this.searchQuery = event.detail.searchQuery;
                                this.filterProducts();
                            });

                            await this.loadCategories();
                            await this.loadProducts();
                            this.filterProducts();
                        } catch (error) {
                            console.error('Error during initialization:', error);
                            // Ensure arrays are initialized even if API fails
                            this.categories = this.categories || [];
                            this.products = this.products || [];
                            this.filteredProducts = this.filteredProducts || [];
                        } finally {
                            this.loading = false;
                        }
                    },

                    async loadCategories() {
                        try {
                            const response = await fetch(`${window.API_BASE}/categories`);
                            const data = await response.json();
                            // Handle different response formats
                            if (data.success && Array.isArray(data.data)) {
                                this.categories = data.data;
                            } else {
                                this.categories = [];
                            }
                            console.log('Loaded categories:', this.categories);
                        } catch (error) {
                            console.error('Error loading categories:', error);
                            this.categories = []; // Ensure it's always an array
                        }
                    },

                    async loadProducts() {
                        try {
                            const response = await fetch(`${window.API_BASE}/products`);
                            const data = await response.json();
                            // Handle paginated response
                            if (data.success && data.data && data.data.data) {
                                this.products = data.data.data; // Get products from pagination data
                            } else if (data.success && Array.isArray(data.data)) {
                                this.products = data.data; // Direct array response
                            } else {
                                this.products = []; // Fallback to empty array
                            }
                            console.log('Loaded products:', this.products);
                        } catch (error) {
                            console.error('Error loading products:', error);
                            this.products = []; // Ensure it's always an array
                        }
                    },

                    selectCategory(categoryId) {
                        this.selectedCategory = categoryId;
                        this.filterProducts();
                    },

                    filterProducts() {
                        // Ensure products is always an array
                        if (!Array.isArray(this.products)) {
                            this.products = [];
                        }

                        let filtered = [...this.products];

                        // Filter by category
                        if (this.selectedCategory) {
                            filtered = filtered.filter(product => product.category_id === this.selectedCategory);
                        }

                        // Filter by search query
                        if (this.searchQuery && this.searchQuery.trim() !== '') {
                            const query = this.searchQuery.toLowerCase().trim();
                            filtered = filtered.filter(product => {
                                return product.name.toLowerCase().includes(query) ||
                                    product.description?.toLowerCase().includes(query) ||
                                    product.short_description?.toLowerCase().includes(query) ||
                                    product.sku.toLowerCase().includes(query);
                            });
                        }

                        this.filteredProducts = filtered;
                        this.sortProducts();
                    },

                    sortProducts() {
                        // Ensure filteredProducts is always an array
                        if (!Array.isArray(this.filteredProducts)) {
                            this.filteredProducts = [];
                            return;
                        }

                        switch (this.sortBy) {
                            case 'price_low':
                                this.filteredProducts.sort((a, b) => (a.sale_price || a.price) - (b.sale_price || b.price));
                                break;
                            case 'price_high':
                                this.filteredProducts.sort((a, b) => (b.sale_price || b.price) - (a.sale_price || a.price));
                                break;
                            case 'name':
                                this.filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
                                break;
                            case 'newest':
                                this.filteredProducts.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                                break;
                            default:
                                // Default sorting
                                break;
                        }
                    },

                    viewProduct(productId) {
                        window.location.href = `/product/${productId}`;
                    },

                    addToCart(product) {
                        try {
                            // Check stock availability
                            if (product.stock_quantity === 0) {
                                this.showNotification('Product is out of stock', 'error');
                                return;
                            }

                            // Use global app store
                            const success = this.$store.appStore.addToCart(product);
                            if (success) {
                                this.showNotification(`${product.name} added to cart!`, 'success');
                            } else {
                                this.showNotification('Failed to add product to cart', 'error');
                            }
                        } catch (error) {
                            console.error('Error adding to cart:', error);
                            this.showNotification('Error adding product to cart', 'error');
                        }
                    },

                    buyNow(product) {
                        try {
                            // Check stock availability
                            if (product.stock_quantity === 0) {
                                this.showNotification('Product is out of stock', 'error');
                                return;
                            }

                            // Add to cart and redirect to checkout
                            const success = this.$store.appStore.addToCart(product);
                            if (success) {
                                window.location.href = '/checkout';
                            } else {
                                this.showNotification('Failed to add product to cart', 'error');
                            }
                        } catch (error) {
                            console.error('Error during buy now:', error);
                            this.showNotification('Error processing purchase', 'error');
                        }
                    },

                    showNotification(message, type = 'success') {
                        this.notification = { show: true, message, type };
                        setTimeout(() => {
                            this.notification.show = false;
                        }, 3000);
                    }
                }
            }
        </script>
    @endpush
@endsection