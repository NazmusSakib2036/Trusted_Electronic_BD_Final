<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Trusted Electronics BD')</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />

    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .product-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .category-card {
            transition: all 0.3s ease;
        }

        .category-card:hover {
            transform: scale(1.05);
        }

        .cart-count {
            animation: bounce 0.5s ease-in-out;
        }

        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-10px);
            }

            60% {
                transform: translateY(-5px);
            }
        }

        /* WhatsApp button styles */
        .whatsapp-fixed-btn {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 9999;
            padding: 16px;
            border-radius: 9999px;
            background-color: #25D366 !important;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .whatsapp-fixed-btn:hover {
            background-color: #128C7E !important;
            transform: scale(1.1);
        }

        .whatsapp-fixed-btn .fa-whatsapp {
            color: white !important;
            font-size: 32px !important;
            line-height: 1;
        }

        /* Minor responsiveness improvements for search */
        .header-search-container {
            width: 100%;
            max-width: 640px;
        }

        /* * UPDATED FIX: 
         * Custom class for centered footer column content on ALL screen sizes.
         * The only change needed was removing the media query override from the previous version.
         */
        .footer-col-center {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        /* Custom class for left alignment on mobile, required for this project */
        .footer-col-flexstart {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            text-align: left;
        }
    </style>

    @stack('styles')
</head>

<body class="bg-gray-50" x-data="appStore()" x-init="init()">
    <div class="bg-red-600 text-white text-center py-2 text-sm cursor-pointer">
        <marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
            <b>Trusted Electronic BD</b> - তে আপনাকে স্বাগতম। বিশেষ অফার: আজই অর্ডার করুন এবং ১৫% ছাড় পান!
        </marquee>
    </div>

    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="max-w-4xl mx-auto px-4">

            <div class="flex items-center justify-between py-3 md:py-4 space-x-4">

                <div class="flex-shrink-0">
                    <a href="/"><img style="height: 50px; width: auto;" src="{{ asset('storage/app/public/products/logo.jpg') }}"
                            alt="Trusted Electronics BD" class="h-8 md:h-12"></a>
                </div>

                <div class="flex-grow">
                    <div class="flex-grow">
                        <div class="relative w-full">
                            <input type="text" x-model="searchQuery" @keyup.enter="searchProducts()"
                                placeholder="পণ্য খুঁজুন..."
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base md:text-lg pr-14">

                            <button @click="searchProducts()"
                                class="absolute right-0 top-0 bottom-0 px-4 rounded-r-lg bg-blue-500 text-white hover:bg-blue-600 transition duration-150 flex items-center">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="flex-shrink-0">
                    <a href="/cart" class="relative block">
                        <svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M17 13v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6" />
                        </svg>
                        <span x-show="$store.appStore.cartCount > 0" x-text="$store.appStore.cartCount"
                            class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center cart-count"></span>
                    </a>
                </div>

            </div>

        </div>
    </header>

    <main>
        @yield('content')
    </main>

    <footer class="bg-gray-800 text-white py-12 mt-16">
        <div class="max-w-4xl mx-auto px-4" style="justify-content: center; align-items: center;">
            <div class="grid grid-cols-1 gap-8 md:grid-cols-4">

                <div class="footer-col-flexstart">
                    <div class="mb-4">
                        <img style="height: 50px; width: auto;" src="{{ asset('storage/app/public/products/logo.jpg') }}"
                            alt="Trusted Electronics BD" class="h-10">
                    </div> <br>
                    <div class="flex space-x-4">
                        <a href="https://www.facebook.com/profile.php?id=61561476570628" target="_blank" class="text-white hover:text-blue-500 transition duration-150"
                            aria-label="Facebook">
                            <i class="fab fa-facebook-square" style="font-size: 1.9rem !important;"></i>
                        </a>
                        <a href="https://www.youtube.com/@trustedelectronicbd1" target="_blank" class="text-white hover:text-red-500 transition duration-150" aria-label="YouTube">
                            <i class="fab fa-youtube-square" style="font-size: 1.9rem !important;"></i>
                        </a>
                    </div>
                </div>

                <div class="footer-col-flexstart">
                    <h3 class="font-semibold mb-4 text-lg">Policies</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="/about-us" class="hover:text-blue-400 transition duration-150">About Us</a></li>
                        <li><a href="" class="hover:text-blue-400 transition duration-150">Privacy Policy</a></li>
                        <li><a href="" class="hover:text-blue-400 transition duration-150">Terms And Conditions</a>
                        </li>
                        <li><a href="" class="hover:text-blue-400 transition duration-150">Return And Cancellation
                                Policy</a></li>
                    </ul>
                </div>

                <div class="footer-col-flexstart">
                    <h3 class="font-semibold mb-4 text-lg">Contact Us</h3>
                    <div class="space-y-2 text-sm">
                        <p><a href="mailto:trustedelectronicbd.info@gmail.com"
                                class="hover:text-blue-400 transition duration-150">trustedelectronicbd.info@gmail.com</a>
                        </p>
                        <p><a href="tel:+8801888058362"
                                class="hover:text-blue-400 transition duration-150">+8801888058362</a></p>
                        <p>Savar Heymatpur (Singair, Manikgonj)</p>
                    </div>
                </div>

                <div class="hidden md:block"></div>

            </div>

            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-sm">
                <p>© 2025 - Copyright Trusted Electronic BD | Design & Development by <b><a
                            href="https://fabtechit.com/" target="_blank"
                            class="text-blue-400 hover:text-blue-300 transition duration-150">FabTech.IT</a></b></p>
            </div>
        </div>
    </footer>

    <a href="https://wa.me/8801888058362" title="Chat on WhatsApp" class="whatsapp-fixed-btn" target="_blank"
        aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script>
        // Set API base URL
        window.API_BASE = '{{ url("/api") }}';

        // Initialize Alpine stores
        document.addEventListener('alpine:init', () => {
            Alpine.store('appStore', {
                searchQuery: '',
                cartCount: 0,
                cartItems: [],
                appliedCoupon: null,
                shippingArea: '',

                init() {
                    this.loadCartFromStorage();
                    this.loadCouponFromStorage();
                    this.loadShippingFromStorage();
                },

                loadCartFromStorage() {
                    const cart = localStorage.getItem('cart');
                    if (cart) {
                        this.cartItems = JSON.parse(cart);
                        this.updateCartCount();
                    }
                },

                loadCouponFromStorage() {
                    const coupon = localStorage.getItem('appliedCoupon');
                    if (coupon) {
                        this.appliedCoupon = JSON.parse(coupon);
                    }
                },

                loadShippingFromStorage() {
                    const shipping = localStorage.getItem('shippingArea');
                    if (shipping) {
                        this.shippingArea = shipping;
                    }
                },

                saveShippingToStorage() {
                    if (this.shippingArea) {
                        localStorage.setItem('shippingArea', this.shippingArea);
                    } else {
                        localStorage.removeItem('shippingArea');
                    }
                },

                saveCouponToStorage() {
                    if (this.appliedCoupon) {
                        localStorage.setItem('appliedCoupon', JSON.stringify(this.appliedCoupon));
                    } else {
                        localStorage.removeItem('appliedCoupon');
                    }
                },

                applyCoupon(coupon) {
                    this.appliedCoupon = coupon;
                    this.saveCouponToStorage();
                },

                removeCoupon() {
                    this.appliedCoupon = null;
                    this.saveCouponToStorage();
                },

                updateCartCount() {
                    this.cartCount = this.cartItems.reduce((total, item) => total + item.quantity, 0);
                },

                addToCart(product, quantity = 1) {
                    console.log('Adding to cart:', product);

                    if (!product || !product.id) {
                        console.error('Invalid product data:', product);
                        return false;
                    }

                    const existingItem = this.cartItems.find(item => item.id === product.id);

                    if (existingItem) {
                        existingItem.quantity += quantity;
                        console.log('Updated existing item quantity:', existingItem);
                    } else {
                        const cartItem = {
                            id: product.id,
                            name: product.name,
                            price: product.sale_price || product.price,
                            image: product.images && product.images.length > 0 ? product.images[0] : null,
                            quantity: quantity
                        };
                        this.cartItems.push(cartItem);
                        console.log('Added new item to cart:', cartItem);
                    }

                    this.saveCartToStorage();
                    this.updateCartCount();

                    console.log('Cart items after addition:', this.cartItems);
                    console.log('Cart count after addition:', this.cartCount);

                    return true;
                },

                removeFromCart(productId) {
                    this.cartItems = this.cartItems.filter(item => item.id !== productId);
                    this.saveCartToStorage();
                    this.updateCartCount();
                },

                updateCartItemQuantity(productId, quantity) {
                    const item = this.cartItems.find(item => item.id === productId);
                    if (item) {
                        if (quantity <= 0) {
                            this.removeFromCart(productId);
                        } else {
                            item.quantity = quantity;
                            this.saveCartToStorage();
                            this.updateCartCount();
                        }
                    }
                },

                saveCartToStorage() {
                    localStorage.setItem('cart', JSON.stringify(this.cartItems));
                },

                clearCart() {
                    this.cartItems = [];
                    this.cartCount = 0;
                    this.appliedCoupon = null;
                    this.shippingArea = '';
                    localStorage.removeItem('cart');
                    localStorage.removeItem('appliedCoupon');
                    localStorage.removeItem('shippingArea');
                },

                getCartTotal() {
                    return this.cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
                }
            });
        });

        function appStore() {
            return {
                searchQuery: '',

                init() {
                    // Initialize the global store
                    this.$store.appStore.init();

                    // Sync with URL search parameters
                    const urlParams = new URLSearchParams(window.location.search);
                    const searchParam = urlParams.get('search');
                    if (searchParam) {
                        this.searchQuery = decodeURIComponent(searchParam);
                    }

                    // Listen for URL changes (back/forward navigation)
                    window.addEventListener('popstate', () => {
                        const urlParams = new URLSearchParams(window.location.search);
                        const searchParam = urlParams.get('search');
                        this.searchQuery = searchParam ? decodeURIComponent(searchParam) : '';
                    });
                },

                searchProducts() {
                    console.log('Navigation search triggered with query:', this.searchQuery);

                    if (this.searchQuery.trim()) {
                        // Check if we're on a page that has search functionality
                        const currentPath = window.location.pathname;
                        console.log('Current path:', currentPath);

                        if (currentPath === '/' || currentPath === '/products') {
                            // Update the URL with search parameter without page reload
                            const url = new URL(window.location);
                            url.searchParams.set('search', this.searchQuery);
                            window.history.pushState({}, '', url);

                            // Dispatch custom event for pages to handle
                            window.dispatchEvent(new CustomEvent('navigationSearch', {
                                detail: {
                                    searchQuery: this.searchQuery
                                }
                            }));
                            console.log('Dispatched navigationSearch event');
                        } else {
                            // Redirect to products page with search
                            console.log('Redirecting to products page');
                            window.location.href = `/products?search=${encodeURIComponent(this.searchQuery)}`;
                        }
                    } else {
                        console.log('Empty search query');
                    }
                }
            }
        }
    </script>

    @stack('scripts')
</body>

</html>